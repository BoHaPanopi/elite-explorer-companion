import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],

  server: {
    port: 5173,
    strictPort: true,

    watch: {
      ignored: ["**/src-tauri/**"],
    },
  },

  clearScreen: false,
});